/* eslint-disable */
export const protobufPackage = "cosmos.msg.v1";
