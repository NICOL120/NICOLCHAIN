package keeper

import (
	"NICOTEEN/x/nicoteen/types"
)

var _ types.QueryServer = Keeper{}
